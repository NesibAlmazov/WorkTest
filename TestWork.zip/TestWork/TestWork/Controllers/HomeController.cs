﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TestWork.DAL;
using TestWork.Models;
using TestWork.ViewModels;

namespace TestWork.Controllers
{
    public class HomeController : Controller

    {
        public AppDbContext _db;

        public HomeController(AppDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            //ViewBag.PageCount = Math.Ceiling((decimal)_db.Allnews.Count() / 6);
            //if (page == null)
            //{
            //    ViewBag.Page = 0;
            //    IndexVM indexx = new IndexVM
            //    {
            //        allnew = _db.Allnews.Take(6),
            //        sportN = _db.SportN,
            //        slides = _db.Slides,
            //        sideName = _db.SideNames.FirstOrDefault()
            //    };
            //    return View(indexx);
            //}
            //ViewBag.Page = page;
            //IndexVM index = new IndexVM
            //{
            //    allnew = _db.Allnews.OrderByDescending(x=>x.Id).Skip(6 * (int)page).Take(6),
            //    sportN = _db.SportN,
            //    slides = _db.Slides,
            //    sideName = _db.SideNames.FirstOrDefault()
            //};
            //return View(index);

            IndexVM index = new IndexVM
            {

                formDatas = _db.FormDatas.OrderByDescending(x => x.Id).Take(6),
                sportN = _db.SportN.OrderByDescending(x => x.Id).Take(6),
                slides = _db.Slides,
                sideName = _db.SideNames.FirstOrDefault(b => b.Id == 1)
            };
           

            return View(index);


        }

        public IActionResult DayN(int? page)
        {
            ViewBag.PageCount = Math.Ceiling((decimal)_db.Allnews.Count() / 6);
            if (page == null)
            {
                ViewBag.Page = 0;
                IndexVM dayx = new IndexVM
                {
                    allnew = _db.Allnews.OrderByDescending(x => x.Id).Take(6),
                    sideName = _db.SideNames.FirstOrDefault()
                };
                return View(dayx );
            }
            ViewBag.Page = page;
            IndexVM day = new IndexVM
            {
                allnew = _db.Allnews.OrderByDescending(x => x.Id).Skip(6 * (int)page).Take(6),
                sideName = _db.SideNames.FirstOrDefault()
            };
            return View(day);


        }

        public IActionResult SportN(int? page)
        {
            ViewBag.PageCount = Math.Ceiling((decimal)_db.SportN.Count() / 6);
            if (page == null)
            {
                ViewBag.Page = 0;
                IndexVM sportx = new IndexVM
                {
                    sportN = _db.SportN.OrderByDescending(x => x.Id).Take(6),
                    sideName = _db.SideNames.FirstOrDefault()
                };
                return View(sportx);
            }
            ViewBag.Page = page;
            IndexVM sport = new IndexVM
            {
                sportN = _db.SportN.OrderByDescending(x => x.Id).Skip(6 * (int)page).Take(6),
                sideName = _db.SideNames.FirstOrDefault()
            };
            return View(sport);


        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
