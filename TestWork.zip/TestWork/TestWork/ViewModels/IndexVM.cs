﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestWork.Areas.Dashboard.Models;
using TestWork.Models;

namespace TestWork.ViewModels
{
    public class IndexVM
    {
        public IEnumerable <NewsDay> dayn { get; set; }
        public IEnumerable <SportN> sportN { get; set; }
        public IEnumerable <allnew> allnew { get; set; }
        public IEnumerable <Slide> slides { get; set; }
        public IEnumerable <FormDatas> formDatas { get; set; }
        public SideName sideName { get; set; }
    }
}
