﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TestWork.Migrations
{
    public partial class AddColumnName2TableSidename : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Name2",
                table: "SideNames",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Name2",
                table: "SideNames");
        }
    }
}
