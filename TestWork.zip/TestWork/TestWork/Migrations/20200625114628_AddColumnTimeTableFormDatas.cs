﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TestWork.Migrations
{
    public partial class AddColumnTimeTableFormDatas : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "newsDate",
                table: "FormDatas",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "newsTime",
                table: "FormDatas",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "newsDate",
                table: "FormDatas");

            migrationBuilder.DropColumn(
                name: "newsTime",
                table: "FormDatas");
        }
    }
}
