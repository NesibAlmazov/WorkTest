﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TestWork.Migrations
{
    public partial class AddColumnActiveTableCreateSlider : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Acttive",
                table: "Slides",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Acttive",
                table: "Slides");
        }
    }
}
