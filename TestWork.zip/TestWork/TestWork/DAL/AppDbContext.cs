﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestWork.Areas.Dashboard.Models;
using TestWork.Models;


namespace TestWork.DAL
{
    public class AppDbContext : IdentityDbContext<AppUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        { }
        public DbSet<NewsDay> DayN { get; set; }
        public DbSet<allnew> Allnews { get; set; }
        public DbSet<SportN> SportN { get; set; }
        public DbSet<Slide> Slides { get; set; }
        public DbSet<SideName> SideNames { get; set; }
        public DbSet<FormDatas> FormDatas { get; set; }
    }
}
