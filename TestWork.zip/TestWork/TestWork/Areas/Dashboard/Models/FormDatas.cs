﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TestWork.Areas.Dashboard.Models
{
    public class FormDatas
    {
        public int Id { get; set; }
       
        public string newsHeader { get; set; }
        
        public string filenews { get; set; }
        public string newsText { get; set; }
        public string newsDate { get; set; }
        public string newsTime { get; set; }
        [NotMapped]
        public IFormFile Files { get; set; }

    }
}
