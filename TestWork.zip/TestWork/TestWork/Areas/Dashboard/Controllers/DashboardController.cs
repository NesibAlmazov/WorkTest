﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TestWork.Areas.Dashboard.ViewModels;
using TestWork.DAL;
using TestWork.Models;

namespace TestWork.Areas.Dashboard.Controllers
{
    [Area("Dashboard")]
    //[Authorize(Roles = "Admin,Moderator")]
    public class DashboardController : Controller
    {
        private readonly AppDbContext _db;

        public DashboardController(AppDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult AllUser()
        {
            AllUserVM allUser = new AllUserVM
            {
                appUsers = _db.Users

            };
            return View(allUser);
        }

        public IActionResult UserDelete(string id)
        {
            AppUser pro = _db.Users.FirstOrDefault(w => w.Id == id);
            if (pro == null)
            {
                return NotFound();
            }
            return View(pro);

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("UserDelete")]
        public async Task<IActionResult> UserDeletePost(string id)
        {
            AppUser pro = _db.Users.FirstOrDefault(w => w.Id == id);
            if (pro == null)
            {
                return NotFound();
            }

            _db.Users.Remove(pro);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(AllUser));
        }

        public async Task<IActionResult> UserUpdate(string id)
        {
            AppUser users = await _db.Users.FindAsync(id);
            if (users == null)
            {
                return NotFound();
            }
            return View(users);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UserUpdate(string id, AppUser appusers)
        {
            AppUser users = await _db.Users.FindAsync(id);
            if (users == null)
            {
                return NotFound();
            }
            users.Name = appusers.Name;
            users.Surname = appusers.Surname;
            users.UserName = appusers.UserName;
            users.Email = appusers.Email;
            users.PhoneNumber = appusers.PhoneNumber;

            //_db.Entry(per).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(AllUser));
        }

       
        public IActionResult PerDetails(string id)
        {
            AppUser pers = _db.Users.FirstOrDefault(p => p.Id == id);
            if (pers == null)
            {
                return NotFound();
            }
            return View(pers);
        }



        public IActionResult UserDelete1(string id)
        {
            AppUser pro = _db.Users.FirstOrDefault(w => w.Id == id);
            if (pro == null)
            {
                return NotFound();
            }
            return View(pro);

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("UserDelete1")]
        public async Task<IActionResult> UserDelete1Post(string id)
        {
            AppUser pro = _db.Users.FirstOrDefault(w => w.Id == id);
            if (pro == null)
            {
                return NotFound();
            }

            _db.Users.Remove(pro);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(AllUser));
        }

    }
}