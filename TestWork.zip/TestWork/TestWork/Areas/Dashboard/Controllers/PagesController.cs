﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using TestWork.Areas.Dashboard.ViewModels;
using TestWork.DAL;
using TestWork.Models;
using Microsoft.AspNetCore.Http;
using System.Net.Http.Headers;
using TestWork.Extensions;
using TestWork.Areas.Dashboard.Models;
using Microsoft.EntityFrameworkCore;

namespace TestWork.Areas.Dashboard.Controllers
{
    [Area("Dashboard")]
    //[Authorize(Roles = "Admin,Moderator")]

    public class PagesController : Controller
    {
        private readonly AppDbContext _db;
        private readonly IHostingEnvironment _env;

        public PagesController(AppDbContext db, IHostingEnvironment env)
        {
            _db = db;
            _env = env;
        }

        public IActionResult DayN()
        {
            AllUserVM day = new AllUserVM
            {
                formDatas = _db.FormDatas,
                allnews = _db.Allnews
            };
            return View(day);
        }

        public IActionResult DayUpload()
        {

            AllUserVM day = new AllUserVM
            {
                
                allnews = _db.Allnews
            };
            return View(day);
        }




#region Comment

        //[HttpPost]

        //public async Task<IActionResult> DayUpload(FormDatas alln)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return View(alln);
        //    }

        //    string File = alln.filenews;
        //    alln.filenews = await alln.Files.SaveFileAsync(_env.WebRootPath, "img");

        //    await _db.FormDatas.AddAsync(alln);
        //    await _db.SaveChangesAsync();
        //    return RedirectToAction(nameof(DayN));
        //}





        //[HttpPost]
        //public async Task<IActionResult> DayUpload(IList<IFormFile> files)
        //{
        //    foreach (IFormFile source in files)
        //    {
        //        string filename = ContentDispositionHeaderValue.Parse(source.ContentDisposition).FileName.Trim('"');

        //        filename = this.EnsureCorrectFilename(filename);

        //        using (FileStream output = System.IO.File.Create(this.GetPathAndFilename(filename)))
        //            await source.CopyToAsync(output);
        //    }

        //    return this.View();
        //}

        //private string EnsureCorrectFilename(string filename)
        //{
        //    if (filename.Contains("\\"))
        //        filename = filename.Substring(filename.LastIndexOf("\\") + 1);

        //    return filename;
        //}

        //private string GetPathAndFilename(string filename)
        //{
        //    return this._env.WebRootPath + "\\img\\" + filename;
        //}



        //[HttpPost]
        //public ActionResult SaveData(IFormFile item)
        //{


        //    return Content(item.ContentType);
        //}


        //    [HttpPost]
        //    public JsonResult SaveData (FormDatas item)
        //    {
        //        var file = item.Files;

        //        if (file != null)
        //        {
        //            var filename = Path.GetFileName(file.FileName);
        //        var extention = Path.GetExtension(file.FileName);
        //        var filenamewithoutextension = Path.GetFileNameWithoutExtension(file.FileName);

        //        item.SaveAs( context.Server.MapPath("/UploadedImage/" + file.FileName));
        //            var path = Path.Combine(_env.WebRootPath, "Sample.PNG");

        //        }

        //        return Json(file., JsonRequestBehavior.AllowGet);
        //}


        // isleyir
        //[HttpPost]
        //public async Task<IActionResult> SaveData(List<IFormFile> files)
        //{
        //    long size = files.Sum(f => f.Length);

        //    foreach (var formFile in files)
        //    {
        //        if (formFile.Length > 0)
        //        {
        //            var filePath = Path.GetTempFileName();

        //            using (var stream = System.IO.File.Create(filePath))
        //            {
        //                await formFile.CopyToAsync(stream);
        //            }
        //        }
        //    }

        //    return Ok(new { count = files.Count, size });
        //}



        //[HttpPost]
        //public async Task<IActionResult> SaveData(IList<IFormFile> files)
        //{
        //    foreach (IFormFile source in files)
        //    {
        //        string filename = ContentDispositionHeaderValue.Parse(source.ContentDisposition).FileName.Trim('"');

        //        filename = this.EnsureCorrectFilename(filename);

        //        using (FileStream output = System.IO.File.Create(this.GetPathAndFilename(filename)))
        //            await source.CopyToAsync(output);
        //    }

        //    return this.View();
        //}

        //private string EnsureCorrectFilename(string filename)
        //{
        //    if (filename.Contains("\\"))
        //        filename = filename.Substring(filename.LastIndexOf("\\") + 1);

        //    return filename;
        //}

        //private string GetPathAndFilename(string filename)
        //{
        //    return this._env.WebRootPath + "\\img\\" + filename;
        //}




        //    [HttpPost]
        //public async Task<IActionResult> SaveData(IList<IFormFile> files)
        //{
        //    foreach (IFormFile source in files)
        //    {
        //        string filename = ContentDispositionHeaderValue.Parse(source.ContentDisposition).FileName.ToString().Trim('"');

        //        filename = this.EnsureCorrectFilename(filename);

        //        using (FileStream output = System.IO.File.Create(this.GetPathAndFilename(filename)))
        //            await source.CopyToAsync(output);
        //    }

        //    return this.View();
        //}

        //private string EnsureCorrectFilename(string filename)
        //{
        //    if (filename.Contains("\\"))
        //        filename = filename.Substring(filename.LastIndexOf("\\") + 1);

        //    return filename;
        //}

        //private string GetPathAndFilename(string filename)
        //{
        //    string path = this._env.WebRootPath + "\\img\\";

        //    if (!Directory.Exists(path))
        //        Directory.CreateDirectory(path);

        //    return path + filename;
        //}


        //[HttpPost] active and guid
        //public async Task<IActionResult> SaveData(IList<IFormFile> files)
        //{
        //    foreach (IFormFile source in files)
        //    {
        //        string filename = ContentDispositionHeaderValue.Parse(source.ContentDisposition).FileName.ToString().Trim('"');

        //        filename = this.EnsureCorrectFilename(filename);

        //        using (FileStream output = System.IO.File.Create(this.GetPathAndFilename(filename)))
        //            await source.CopyToAsync(output);
        //    }

        //    return this.View();
        //}

        //private string EnsureCorrectFilename(string filename)
        //{
        //    if (filename.Contains("\\"))
        //        filename = filename.Substring(filename.LastIndexOf("\\") + 1);

        //    return filename;
        //}

        //private string GetPathAndFilename(string filename)
        //{
        //    string uniqueId = Guid.NewGuid().ToString();
        //    string newFileName = uniqueId + filename;
        //    string path = this._env.WebRootPath + "\\img\\" + @"\" + newFileName;

        //    if (!Directory.Exists(path))
        //        Directory.CreateDirectory(path);

        //    return path + filename;
        //}

#endregion
                                                  
        [HttpPost]
        public async Task<IActionResult> SaveData(FormDatas item)
        {
            
            if (!ModelState.IsValid)
            {
                return View(item);
            }

            if (item.Files == null)
            {
                ModelState.AddModelError("File", "Photo should be selected");
                return View(item);
            }

            if (!item.Files.IsImage())
            {
                ModelState.AddModelError("File", "Photo is not valid");
                return View(item);
            }


            item.filenews = await item.Files.SaveFileAsync(_env.WebRootPath, "DayN");

            await _db.FormDatas.AddAsync(item);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(DayN));
        }

        }
}








