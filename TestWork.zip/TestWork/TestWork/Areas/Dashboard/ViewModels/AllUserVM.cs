﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestWork.Areas.Dashboard.Models;
using TestWork.Models;

namespace TestWork.Areas.Dashboard.ViewModels
{
    public class AllUserVM
    {
        public IEnumerable<AppUser> appUsers { get; set; }
        public IEnumerable<allnew> allnews { get; set; }
        public IEnumerable<SportN> sportNs { get; set; }
        public IEnumerable<FormDatas> formDatas { get; set; }
    }
}
