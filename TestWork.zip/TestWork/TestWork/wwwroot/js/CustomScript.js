﻿function confirmdelete(uniqueId, isDeleteClicked) {
    var deletespan = 'deletespan_' + uniqueId;
    var confirmdelete = 'confirmdelete_' + uniqueId;
    
    if (isDeleteClicked) {
        $('#' + deletespan).hide();
        $('#' + confirmdelete).show();
    }
    else {
        $('#' + deletespan).show();
        $('#' + confirmdelete).hide();
    }

}