﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestWork.Helpers
{
    public class UR
    {
        public enum Roles
        {
            Admin,
            Moderator,
            User

        }
        public const string AdminRole = "Admin";
        public const string MemberRole = "Moderator";
        public const string UserRole = "User";
    }
}
